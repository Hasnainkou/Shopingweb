import './App.css';
import Signup from "./Signup";
import Menupage from "./Menupage";





function App() {
  return ( <>

{/* <Signup/> */}
<Menupage/>

</>
  );
}

export default App;
